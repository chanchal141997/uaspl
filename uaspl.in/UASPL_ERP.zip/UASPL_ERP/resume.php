<?php include './pages/db.php' ?>


<?php 
if(isset($_POST['submit'])){
$name=$_POST['name'];
$email=$_POST['email'];
$no=$_POST['no'];
$qualification=$_POST['qualification'];
$resume = $_FILES['resume'];


$filename = $resume['name'];
$filerrror = $resume['error'];
$filetmp = $resume['tmp_name'];
$fileext = explode('.', $filename);
$filecheck = strtolower(end($fileext));
$fileextstored = array('png', 'pdf', 'jpeg');

$destinationfile = '../resume/' . $filename;

move_uploaded_file($filetmp, $destinationfile);
$sql="INSERT INTO `resume`(`name`, `email`, `no`, `qualification`, `resume`) VALUES ('$name','$emial','$no','$qualification','$destinationfile')";
$query=mysqli_query($connection,$sql);
if($query){
    echo '<script> alert("Resume sent successfully.....")</script>';
}else{
    echo "not inserted";
}
}
else{
    echo "invalid";
}