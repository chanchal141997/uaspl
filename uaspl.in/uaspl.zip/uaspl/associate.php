<?php include('header.php'); ?>
<!--Page Title-->
<section class="page-title" style="background-image:url(images/team.png);">
    <div class="auto-container">
        <h1>Associates Behind UASPL</h1>
    </div>
</section>

<!--Page Info-->
<section class="page-info">
    <div class="auto-container clearfix">
        <div class="pull-left">
            <h2>OUR ASSOCIATES</h2>
        </div>
        <div class="pull-right">
            <ul class="bread-crumb clearfix">
                <li><a href="index-2.html">Home</a></li>

                <li>Associates</li>
            </ul>
        </div>
    </div>
</section>

<!--Team Section One-->
<section class="team-section-one">
    <div class="auto-container">

        <div class="row clearfix">
            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">

                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">Adv. Santosh Yadav</a></h3>
                        <div class="designation">LEGAL EXPERTS</div>
                        
                    </div>
                </div>
            </div>



            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">Adv. Raj Khude</a></h3>
                        <div class="designation">LEGAL EXPERTS</div>
                       

                    </div>
                </div>
            </div>

            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">DIGSS CONSULTANCY </a></h3>
                        <div class="designation">M.E.P. CONSULATANTS</div>
                    
                    </div>
                </div>
            </div>

            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">S.P. Enterprises </a></h3>
                        <div class="designation">LAND SURVEYOR</div>

                    </div>
                </div>
            </div>

</div>
<div class="row clearfix">

            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">S & J Associate </a></h3>
                        <div class="designation">LAND SURVEYOR</div>
                
                    </div>
                </div>
            </div>

            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">Mr. Prashant Agrawal</a></h3>
                        <div class="designation">GOVERNMENT VALUER</div>
                       
                    </div>
                </div>
            </div>
            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">Mr. Rohit Mali </a></h3>
                        <div class="designation">ADMINISTRATIVE DEPARTMENT</div>
                        
                    </div>
                </div>
            </div>
            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">Ms. Nikita jadhav</a></h3>
                        <div class="designation">ADMINISTRATIVE DEPARTMENT</div>
                    </div>
                </div>
            </div>

</div> <div class="row clearfix">
            <!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">Mr. Vinayak Mangarshi</a></h3>
                        <div class="designation">CIVIL ENGINEER</div>
                        
                    </div>
                </div>
            </div><!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html"> Mr. Avinash Patil</a></h3>
                        <div class="designation">CIVIL ENGINEER</div>
                        
                    </div>
                </div>
            </div><!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">Mr. Utkarsh Shinde</a></h3>
                        <div class="designation">CIVIL ENGINEER</div>
                        
                    </div>
                </div>
            </div><!--Team Member-->
            <div class="team-member-one col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <figure class="image-box">
                        <img src="images/resource/team-image-5.jpg" alt="">
                        <div class="overlay">
                            <ul class="social-links">
                                <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                                <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </figure>
                    <div class="lower-content">
                        <h3><a href="team-single.html">Mr. Subhash Patil</a></h3>
                        <div class="designation">SOCIETY MATTER EXPERT</div>
                        
                    </div>
                </div>
            </div>

            </div>
           

    </div>
</section>





<?php include('footer.php'); ?>